/** Gtk utilities */

export function addChildToBox(box, child) {
    box.append(child);
}
